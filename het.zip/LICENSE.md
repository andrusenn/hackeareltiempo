# LICENSE

Hackear el tiempo -
Use the images and code as you wish under (CC BY 4.0) and make your own style ;)

p5js -
GNU Lesser General Public License v2.1